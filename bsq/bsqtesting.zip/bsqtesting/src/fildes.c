/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fildes.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anunes-d <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/11 20:24:18 by anunes-d          #+#    #+#             */
/*   Updated: 2020/11/11 20:24:38 by anunes-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int		fildes(int argc, char *argv[], int map)
{
	int		fd;

	fd = 1;
	if (argc == 1)
		fd = 0;
	else if ((fd = open(argv[map], O_RDONLY)) == -1)
		write(1, "map error\n", 10);
	return (fd);
}
